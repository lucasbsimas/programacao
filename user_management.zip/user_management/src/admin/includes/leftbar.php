<nav class="ts-sidebar">
  <ul class="ts-sidebar-menu">
    <li class="ts-label">Main</li>
    <li><a href="dashboard.php"><i class="fa fa-dashboard"></i> Dashboard</a></li>
    <li><a href="userlist.php"><i class="fa fa-users"></i>Userlist</a></li>
    <li><a href="profile.php"><i class="fa fa-user"></i>&nbsp;Profile</a></li>
    <li><a href="feedback.php"><i class="fa fa-envelope"></i>&nbsp;Feedback</a></li>
    <li><a href="notification.php"><i class="fa fa-bell"></i>&nbsp;Notification <sup style="color:red">*</sup></a></li>
    <li><a href="deleteduser.php"><i class="fa fa-user-times"></i>&nbsp;Deleted Users</a></li>
    <li><a href="download.php"><i class="fa fa-download"></i>&nbsp;Download Users-List</a></li>
  </ul>
  <p class="text-center" style="color:#ffffff; margin-top:100px;">© Ajay</p>
</nav>
