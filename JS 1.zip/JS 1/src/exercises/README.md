# 1

Marcos comprou um ingresso para ver um show e pagou R$170,00. Só que na última hora surgiu um imprevisto, e Marcos não poderá mais ir. Ele anunciou no Twitter que estava vendendo seu ingresso, e recebeu várias propostas. Escreva um algoritmo que solicite a Marcos que informe o valor de uma proposta e depois mostre na tela a diferença entre o valor que ele pagou pelo ingresso e o valor da proposta recebida.

# 2

Um usuário do Facebook compartilha 6 links por dia. Para cada link que ele compartilha, 8 contatos dão “curtir” na sua publicação. Escreva um algoritmo que solicite ao usuário a quantidade de dias e mostre na tela a quantidade de “curtir” que ele recebe nesses dias.

# 3

Um aluno desatento acessa o Twitter nas aulas de algoritmos e twitta várias vezes durante as aulas. Escreva um algoritmo que solicite ao usuário o número de tweets que o aluno escreve por aula e calcule quantas vezes o aluno desatento irá twittar em um ano, sabendo que um ano possui 4 bimestres, e cada bimestre possui 20 aulas.

# 4

O mesmo aluno da questão 3 vai perder um ponto na média final da disciplina de algoritmos para cada 100 tweets que escrever. Escreva um algoritmo que solicite ao usuário a nota inicial do aluno, o número de tweets do aluno no ano, calcule a sua nota final e mostre na tela.

# 5

Um casal de namorados aluga dois filmes: um romântico e um de investigação. O filme romântico tem 90 minutos. Durante esse filme, o garoto dorme a maioria do tempo, e a garota fica acordada o tempo inteiro. O filme de investigação tem 110 minutos. Durante esse filme, a garota dorme na maioria do tempo, e o garoto fica acordado o tempo inteiro. Escreva um algoritmo que solicite ao usuário o tempo de sono de cada pessoa, depois calcule e mostre na tela quanto tempo cada um ficou acordado assistindo os filmes.

# 6

Um gamer joga um RPG (jogo de vídeo game) que leva no mínimo 78 horas para ser completado. Escreva um algoritmo que solicite que o usuário informe quantas horas por dia o gamer pode jogar, e depois calcule e mostre na tela quantos dias o gamer vai demorar para completar o jogo.

# 7

Na festa de São João do IFC, os alunos do terceiro ano irão vender pipoca para arrecadar dinheiro para pagar sua formatura. Eles gastaram R$ 150,00 comprando os itens suficientes para produzir 250 saquinhos de pipoca. Escreva um algoritmo que calcule o valor pelo qual deve ser vendido cada saquinho de pipoca para que o lucro final da turma seja de R$ 350,00.
